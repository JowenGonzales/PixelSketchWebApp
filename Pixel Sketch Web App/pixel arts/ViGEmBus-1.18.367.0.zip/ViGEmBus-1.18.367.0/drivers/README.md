# Drivers directory

Place the attestation signed driver files into the corresponding sub-directories and locally build the setup and sign it afterwards for production release.
